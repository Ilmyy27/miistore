<?php
// Text
$_['text_success']     = 'Success: API session successfully started!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to access the API!';
$_['error_key']        = 'Warning: Incorrect API Key!';
$_['error_ip']         = 'Warning: Your IP %s is not allowed to access this API!';