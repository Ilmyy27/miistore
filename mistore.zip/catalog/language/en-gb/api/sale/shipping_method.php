<?php
// Text
$_['text_success']           = 'Success: Shipping method has been set!';

// Error
$_['error_shipping_address'] = 'Warning: Shipping address required!';
$_['error_shipping_method']  = 'Warning: Shipping method required!';
$_['error_no_shipping']      = 'Warning: No Shipping options are available!';
$_['error_shipping']         = 'Warning: There are no products that require shipping';