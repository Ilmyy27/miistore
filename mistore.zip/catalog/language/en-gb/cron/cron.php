<?php
// Text
$_['text_success']     = 'Success: You have run %s cron job!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify cron jobs!';